﻿namespace testIVEQ
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_VTC = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_IT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_IW = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_FP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_len = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_AW = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tb_VTC
            // 
            this.tb_VTC.Location = new System.Drawing.Point(88, 69);
            this.tb_VTC.Margin = new System.Windows.Forms.Padding(2);
            this.tb_VTC.Name = "tb_VTC";
            this.tb_VTC.Size = new System.Drawing.Size(79, 21);
            this.tb_VTC.TabIndex = 37;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(32, 73);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 16);
            this.label6.TabIndex = 36;
            this.label6.Text = "VTC";
            // 
            // tb_IT
            // 
            this.tb_IT.Location = new System.Drawing.Point(249, 70);
            this.tb_IT.Margin = new System.Windows.Forms.Padding(2);
            this.tb_IT.Name = "tb_IT";
            this.tb_IT.Size = new System.Drawing.Size(79, 21);
            this.tb_IT.TabIndex = 35;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(222, 74);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 16);
            this.label4.TabIndex = 34;
            this.label4.Text = "IT";
            // 
            // tb_IW
            // 
            this.tb_IW.Location = new System.Drawing.Point(422, 28);
            this.tb_IW.Margin = new System.Windows.Forms.Padding(2);
            this.tb_IW.Name = "tb_IW";
            this.tb_IW.Size = new System.Drawing.Size(170, 21);
            this.tb_IW.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(396, 32);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 16);
            this.label2.TabIndex = 30;
            this.label2.Text = "IW";
            // 
            // tb_FP
            // 
            this.tb_FP.Location = new System.Drawing.Point(249, 28);
            this.tb_FP.Margin = new System.Windows.Forms.Padding(2);
            this.tb_FP.Name = "tb_FP";
            this.tb_FP.Size = new System.Drawing.Size(79, 21);
            this.tb_FP.TabIndex = 29;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(222, 32);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 16);
            this.label5.TabIndex = 28;
            this.label5.Text = "FP";
            // 
            // tb_len
            // 
            this.tb_len.Location = new System.Drawing.Point(88, 30);
            this.tb_len.Margin = new System.Windows.Forms.Padding(2);
            this.tb_len.Name = "tb_len";
            this.tb_len.Size = new System.Drawing.Size(79, 21);
            this.tb_len.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(32, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 16);
            this.label1.TabIndex = 26;
            this.label1.Text = "Length";
            // 
            // tabControl1
            // 
            this.tabControl1.Location = new System.Drawing.Point(31, 111);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(718, 344);
            this.tabControl1.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(397, 69);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(24, 16);
            this.label3.TabIndex = 42;
            this.label3.Text = "AW";
            // 
            // tb_AW
            // 
            this.tb_AW.Location = new System.Drawing.Point(422, 68);
            this.tb_AW.Margin = new System.Windows.Forms.Padding(2);
            this.tb_AW.Name = "tb_AW";
            this.tb_AW.Size = new System.Drawing.Size(170, 21);
            this.tb_AW.TabIndex = 43;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 490);
            this.Controls.Add(this.tb_AW);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tb_VTC);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.tb_IT);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tb_IW);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_FP);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb_len);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form6";
            this.Text = "Form6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_VTC;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_IT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_IW;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_FP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_len;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_AW;
    }
}