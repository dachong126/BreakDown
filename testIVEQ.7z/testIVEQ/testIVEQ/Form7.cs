﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace testIVEQ
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
         public Form7(string telegram)
        {
            InitializeComponent();
            //构造函数传递过来的值进行解析
            Regex reg = new Regex("VI(.{6})VW(.{48})PL(.{2})");
            Match match = reg.Match(telegram);

            //提取有关信息
            string VI = match.Groups[1].Value;
            string VW = match.Groups[2].Value;
            string PL = match.Groups[3].Value;

            tb_VI.Text = VI;
            tb_VW.Text = VW;
            tb_PL.Text = PL;

        }
    }
}
