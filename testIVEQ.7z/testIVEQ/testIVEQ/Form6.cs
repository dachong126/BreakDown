﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace testIVEQ
{
    public partial class Form6 : Form
    {
        static int AW_value;
        public Form6()
        {
            InitializeComponent();
        }
        public Form6(string telegram)
        {
            InitializeComponent();
            //依次选取对应字段的值
            Regex reg = new Regex("(.{4})(.{5})(.{3})(.{4})FP(.{6})IT(.{12})IW(.{48})AW(.{2})(.+)");
            Match match = reg.Match(telegram);
            string s="VI";
            string e = "VI";

            //把单条QI结果信息拿出来
            Regex regs = new Regex("(?<=(" + s + "))[.\\s\\S]*?(?=(" + e + "))", RegexOptions.Multiline | RegexOptions.Singleline);   //??为什么是202   有用到吗？
            MatchCollection idents = regs.Matches(telegram);   //匹配数组
            //int Index_idents = idents.Count;
            string no = match.Groups[1].Value;
            string length = match.Groups[2].Value;
            string direction = match.Groups[3].Value;
            string type = match.Groups[4].Value;
            string FP = match.Groups[5].Value;
            string IT = match.Groups[6].Value;
            string IW = match.Groups[7].Value;
            string AW = match.Groups[8].Value;
            AW_value = int.Parse(AW);
            //依次解析出八个字段并赋值
            tb_len.Text = length;
            tb_FP.Text = FP;
            tb_IT.Text = IT;
            tb_IW.Text = IW;
            tb_AW.Text = AW;
            tb_VTC.Text = direction;

            for (int j = 0; j < AW_value; j++)
            {
                //解析出单个ident结果信息  赋值Form的够构造函数
                int num = j + 1;
                string squence = "VI" + num.ToString();
                TabPage page = new TabPage(squence);
                //单个ident结果信息传入
                string VI = "VI" + idents[j].ToString();
                Form7 f7 = new Form7(VI);
                
                //设置边框形式
                f7.FormBorderStyle = FormBorderStyle.None;
                //窗口是否显示为顶级窗口
                f7.TopLevel = false;
                f7.ControlBox = false;
                f7.Dock = DockStyle.Fill;
                f7.Show();
                f7.Parent = page;            
                tabControl1.TabPages.Add(page);
               

                      
        }
        }
    }
}
