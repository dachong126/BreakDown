﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace testIVEQ
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(string telegram)
        {
            InitializeComponent();
            //依次选取对应字段的值
            Regex reg = new Regex("(.{4})(.{5})(.{3})(.{4})FP(.{6})IT(.{12})IW(.{48})US(.{8})DA(.{10})ZT(.{8})");
            Match match = reg.Match(telegram);
            tb_Length.Text = match.Groups[2].Value;
            tb_VTC.Text = match.Groups[3].Value;            
            tb_FP.Text = match.Groups[5].Value;
            tb_IT.Text = match.Groups[6].Value;
            tb_IW.Text = match.Groups[7].Value;
            tb_US.Text = match.Groups[8].Value;
            tb_DA.Text = match.Groups[9].Value;
            tb_ZT.Text = match.Groups[10].Value;
        }
    }
}
