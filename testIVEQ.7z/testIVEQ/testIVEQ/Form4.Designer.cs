﻿namespace testIVEQ
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_ZT = new System.Windows.Forms.TextBox();
            this.tb_DA = new System.Windows.Forms.TextBox();
            this.tb_VTC = new System.Windows.Forms.TextBox();
            this.tb_US = new System.Windows.Forms.TextBox();
            this.tb_IW = new System.Windows.Forms.TextBox();
            this.tb_IT = new System.Windows.Forms.TextBox();
            this.tb_FP = new System.Windows.Forms.TextBox();
            this.tb_Length = new System.Windows.Forms.TextBox();
            this.lbl_ZT = new System.Windows.Forms.Label();
            this.lbl_DA = new System.Windows.Forms.Label();
            this.lbl_US = new System.Windows.Forms.Label();
            this.lbl_VTC = new System.Windows.Forms.Label();
            this.lbl_IW = new System.Windows.Forms.Label();
            this.lbl_IT = new System.Windows.Forms.Label();
            this.lbl_FP = new System.Windows.Forms.Label();
            this.lbl_Length = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tb_ZT
            // 
            this.tb_ZT.Location = new System.Drawing.Point(82, 130);
            this.tb_ZT.Name = "tb_ZT";
            this.tb_ZT.Size = new System.Drawing.Size(100, 21);
            this.tb_ZT.TabIndex = 10;
            // 
            // tb_DA
            // 
            this.tb_DA.Location = new System.Drawing.Point(82, 92);
            this.tb_DA.Name = "tb_DA";
            this.tb_DA.Size = new System.Drawing.Size(100, 21);
            this.tb_DA.TabIndex = 11;
            // 
            // tb_VTC
            // 
            this.tb_VTC.Location = new System.Drawing.Point(82, 57);
            this.tb_VTC.Name = "tb_VTC";
            this.tb_VTC.Size = new System.Drawing.Size(100, 21);
            this.tb_VTC.TabIndex = 12;
            // 
            // tb_US
            // 
            this.tb_US.Location = new System.Drawing.Point(407, 57);
            this.tb_US.Name = "tb_US";
            this.tb_US.Size = new System.Drawing.Size(199, 21);
            this.tb_US.TabIndex = 13;
            // 
            // tb_IW
            // 
            this.tb_IW.Location = new System.Drawing.Point(407, 22);
            this.tb_IW.Name = "tb_IW";
            this.tb_IW.Size = new System.Drawing.Size(199, 21);
            this.tb_IW.TabIndex = 14;
            // 
            // tb_IT
            // 
            this.tb_IT.Location = new System.Drawing.Point(243, 57);
            this.tb_IT.Name = "tb_IT";
            this.tb_IT.Size = new System.Drawing.Size(100, 21);
            this.tb_IT.TabIndex = 15;
            // 
            // tb_FP
            // 
            this.tb_FP.Location = new System.Drawing.Point(243, 22);
            this.tb_FP.Name = "tb_FP";
            this.tb_FP.Size = new System.Drawing.Size(100, 21);
            this.tb_FP.TabIndex = 16;
            // 
            // tb_Length
            // 
            this.tb_Length.Location = new System.Drawing.Point(82, 22);
            this.tb_Length.Name = "tb_Length";
            this.tb_Length.Size = new System.Drawing.Size(100, 21);
            this.tb_Length.TabIndex = 17;
            // 
            // lbl_ZT
            // 
            this.lbl_ZT.AutoSize = true;
            this.lbl_ZT.Location = new System.Drawing.Point(22, 133);
            this.lbl_ZT.Name = "lbl_ZT";
            this.lbl_ZT.Size = new System.Drawing.Size(29, 12);
            this.lbl_ZT.TabIndex = 2;
            this.lbl_ZT.Text = "ZT：";
            // 
            // lbl_DA
            // 
            this.lbl_DA.AutoSize = true;
            this.lbl_DA.Location = new System.Drawing.Point(22, 95);
            this.lbl_DA.Name = "lbl_DA";
            this.lbl_DA.Size = new System.Drawing.Size(29, 12);
            this.lbl_DA.TabIndex = 3;
            this.lbl_DA.Text = "DA：";
            // 
            // lbl_US
            // 
            this.lbl_US.AutoSize = true;
            this.lbl_US.Location = new System.Drawing.Point(372, 60);
            this.lbl_US.Name = "lbl_US";
            this.lbl_US.Size = new System.Drawing.Size(29, 12);
            this.lbl_US.TabIndex = 4;
            this.lbl_US.Text = "US：";
            // 
            // lbl_VTC
            // 
            this.lbl_VTC.AutoSize = true;
            this.lbl_VTC.Location = new System.Drawing.Point(22, 63);
            this.lbl_VTC.Name = "lbl_VTC";
            this.lbl_VTC.Size = new System.Drawing.Size(35, 12);
            this.lbl_VTC.TabIndex = 5;
            this.lbl_VTC.Text = "VTC：";
            // 
            // lbl_IW
            // 
            this.lbl_IW.AutoSize = true;
            this.lbl_IW.Location = new System.Drawing.Point(372, 26);
            this.lbl_IW.Name = "lbl_IW";
            this.lbl_IW.Size = new System.Drawing.Size(29, 12);
            this.lbl_IW.TabIndex = 6;
            this.lbl_IW.Text = "IW：";
            // 
            // lbl_IT
            // 
            this.lbl_IT.AutoSize = true;
            this.lbl_IT.Location = new System.Drawing.Point(208, 60);
            this.lbl_IT.Name = "lbl_IT";
            this.lbl_IT.Size = new System.Drawing.Size(29, 12);
            this.lbl_IT.TabIndex = 7;
            this.lbl_IT.Text = "IT：";
            // 
            // lbl_FP
            // 
            this.lbl_FP.AutoSize = true;
            this.lbl_FP.Location = new System.Drawing.Point(208, 26);
            this.lbl_FP.Name = "lbl_FP";
            this.lbl_FP.Size = new System.Drawing.Size(29, 12);
            this.lbl_FP.TabIndex = 8;
            this.lbl_FP.Text = "FP：";
            // 
            // lbl_Length
            // 
            this.lbl_Length.AutoSize = true;
            this.lbl_Length.Location = new System.Drawing.Point(22, 26);
            this.lbl_Length.Name = "lbl_Length";
            this.lbl_Length.Size = new System.Drawing.Size(53, 12);
            this.lbl_Length.TabIndex = 9;
            this.lbl_Length.Text = "Length：";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 177);
            this.Controls.Add(this.tb_ZT);
            this.Controls.Add(this.tb_DA);
            this.Controls.Add(this.tb_VTC);
            this.Controls.Add(this.tb_US);
            this.Controls.Add(this.tb_IW);
            this.Controls.Add(this.tb_IT);
            this.Controls.Add(this.tb_FP);
            this.Controls.Add(this.tb_Length);
            this.Controls.Add(this.lbl_ZT);
            this.Controls.Add(this.lbl_DA);
            this.Controls.Add(this.lbl_US);
            this.Controls.Add(this.lbl_VTC);
            this.Controls.Add(this.lbl_IW);
            this.Controls.Add(this.lbl_IT);
            this.Controls.Add(this.lbl_FP);
            this.Controls.Add(this.lbl_Length);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_ZT;
        private System.Windows.Forms.TextBox tb_DA;
        private System.Windows.Forms.TextBox tb_VTC;
        private System.Windows.Forms.TextBox tb_US;
        private System.Windows.Forms.TextBox tb_IW;
        private System.Windows.Forms.TextBox tb_IT;
        private System.Windows.Forms.TextBox tb_FP;
        private System.Windows.Forms.TextBox tb_Length;
        private System.Windows.Forms.Label lbl_ZT;
        private System.Windows.Forms.Label lbl_DA;
        private System.Windows.Forms.Label lbl_US;
        private System.Windows.Forms.Label lbl_VTC;
        private System.Windows.Forms.Label lbl_IW;
        private System.Windows.Forms.Label lbl_IT;
        private System.Windows.Forms.Label lbl_FP;
        private System.Windows.Forms.Label lbl_Length;
    }
}