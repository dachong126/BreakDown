﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace testIVEQ
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        public Form5(string telegram)
        {
            InitializeComponent();
            //构造函数传递过来的值进行解析
            Regex reg = new Regex("QI(.+)QA(.+)FE(.+)QS(.+)US(.+)DA(.+)ZT(.+)AP(.{2})");
            Match match = reg.Match(telegram);

            //提取有关信息
            string QI = match.Groups[1].Value;
            string QA = match.Groups[2].Value;
            string FE = match.Groups[3].Value;
            string QS = match.Groups[4].Value;
            string US = match.Groups[5].Value;
            string DA = match.Groups[6].Value;
            string ZT = match.Groups[7].Value;
            string AP = match.Groups[8].Value;
            tb_qi.Text = QI;
            tb_qa.Text = QA;
            tb_fe.Text = FE;
            tb_qs.Text = QS;
            tb_us.Text = US;
            tb_da.Text = DA;
            tb_zt.Text = ZT;
            tb_ap.Text = AP;


            
            //处理PI数据组
            Regex regs = new Regex("(PI.{16})");
            MatchCollection PIs = regs.Matches(telegram);

            //新建两个数组对象用于存储信息
            string[] pi = new string[7];
            string[] pw = new string[7]; ;

            int AP_value = int.Parse(AP);
            for (int i = 0; i < AP_value; i++)
            {
                pi[i] = PIs[i].Value.Substring(2, 2);
                pw[i] = PIs[i].Value.Substring(6, 12);
            }
            tb_pi1.Text = pi[0];
            tb_pw1.Text = pw[0];
            tb_pi2.Text = pi[1];
            tb_pw2.Text = pw[1];
            tb_pi3.Text = pi[2];
            tb_pw3.Text = pw[2];
            tb_pi4.Text = pi[3];
            tb_pw4.Text = pw[3];
            tb_pi5.Text = pi[4];
            tb_pw5.Text = pw[4];
            tb_pi6.Text = pi[5];
            tb_pw6.Text = pw[5];
            tb_pi7.Text = pi[6];
            tb_pw7.Text = pw[6];
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

       
      
    }
}
