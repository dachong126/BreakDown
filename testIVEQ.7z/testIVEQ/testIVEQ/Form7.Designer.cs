﻿namespace testIVEQ
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_VI = new System.Windows.Forms.Label();
            this.lbl_PL = new System.Windows.Forms.Label();
            this.tb_VI = new System.Windows.Forms.TextBox();
            this.tb_PL = new System.Windows.Forms.TextBox();
            this.lbl_VW = new System.Windows.Forms.Label();
            this.tb_VW = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_VI
            // 
            this.lbl_VI.AutoSize = true;
            this.lbl_VI.Location = new System.Drawing.Point(27, 26);
            this.lbl_VI.Name = "lbl_VI";
            this.lbl_VI.Size = new System.Drawing.Size(23, 12);
            this.lbl_VI.TabIndex = 0;
            this.lbl_VI.Text = "VI:";
            // 
            // lbl_PL
            // 
            this.lbl_PL.AutoSize = true;
            this.lbl_PL.Location = new System.Drawing.Point(27, 56);
            this.lbl_PL.Name = "lbl_PL";
            this.lbl_PL.Size = new System.Drawing.Size(23, 12);
            this.lbl_PL.TabIndex = 0;
            this.lbl_PL.Text = "PL:";
            // 
            // tb_VI
            // 
            this.tb_VI.Location = new System.Drawing.Point(56, 23);
            this.tb_VI.Name = "tb_VI";
            this.tb_VI.Size = new System.Drawing.Size(100, 21);
            this.tb_VI.TabIndex = 1;
            // 
            // tb_PL
            // 
            this.tb_PL.Location = new System.Drawing.Point(56, 53);
            this.tb_PL.Name = "tb_PL";
            this.tb_PL.Size = new System.Drawing.Size(100, 21);
            this.tb_PL.TabIndex = 1;
            // 
            // lbl_VW
            // 
            this.lbl_VW.AutoSize = true;
            this.lbl_VW.Location = new System.Drawing.Point(27, 94);
            this.lbl_VW.Name = "lbl_VW";
            this.lbl_VW.Size = new System.Drawing.Size(23, 12);
            this.lbl_VW.TabIndex = 0;
            this.lbl_VW.Text = "VW:";
            // 
            // tb_VW
            // 
            this.tb_VW.Location = new System.Drawing.Point(56, 91);
            this.tb_VW.Name = "tb_VW";
            this.tb_VW.Size = new System.Drawing.Size(399, 21);
            this.tb_VW.TabIndex = 1;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 136);
            this.Controls.Add(this.tb_VW);
            this.Controls.Add(this.tb_PL);
            this.Controls.Add(this.tb_VI);
            this.Controls.Add(this.lbl_VW);
            this.Controls.Add(this.lbl_PL);
            this.Controls.Add(this.lbl_VI);
            this.Name = "Form7";
            this.Text = "Form7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_VI;
        private System.Windows.Forms.Label lbl_PL;
        private System.Windows.Forms.TextBox tb_VI;
        private System.Windows.Forms.TextBox tb_PL;
        private System.Windows.Forms.Label lbl_VW;
        private System.Windows.Forms.TextBox tb_VW;
    }
}