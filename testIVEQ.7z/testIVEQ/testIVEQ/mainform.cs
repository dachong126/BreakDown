﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace testIVEQ
{
    public partial class mainform : Form
    {
        string telegram = "";
        public mainform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if (textBox1.Text.Length > 16)
                {
                    string type = textBox1.Text.Substring(12, 4);
                    if (type == "IVEQ")
                    {
                        //获取报文信息   并传入下一个对话框
                        telegram = textBox1.Text + "QI";
                        Form1 f1 = new Form1(telegram);
                        f1.Text = "IVEQ";
                        f1.ShowDialog();
                    }
                    if (type == "MDAV")
                    {
                        telegram = textBox1.Text;
                        Form2 f2 = new Form2(telegram);
                        f2.Text = "MDAV";
                        f2.ShowDialog();
                    }
                    if (type == "AQDV")
                    {
                        telegram = textBox1.Text;
                        Form3 f3 = new Form3(telegram);
                        f3.Text = "AQDV";
                        f3.ShowDialog();
                    }
                    if (type == "MAUV")
                    {
                        telegram = textBox1.Text;
                        Form4 f4 = new Form4(telegram);
                        f4.Text = "MAUV";
                        f4.ShowDialog();
                    }
                    if (type == "MVPA")
                    {
                        telegram = textBox1.Text + "VI";
                        Form6 f6 = new Form6(telegram);
                        f6.Text = "MVPA";
                        f6.ShowDialog();
                    }
                    if (type == "AVPB")
                    {
                        telegram = textBox1.Text + "VI";
                        Form6 f6 = new Form6(telegram);
                        f6.Text = "AVPB";
                        f6.ShowDialog();
                    }

                }
                else
                {
                    MessageBox.Show("请输入报文");
                }
                
               
                
            }
            else {
                MessageBox.Show("未输入内容！请输入");
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
